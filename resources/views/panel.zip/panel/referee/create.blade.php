@extends('layouts.app')
@section('content')

     <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="{{route('home')}}"><i class="fa fa-home"></i> Home</a></li>
                              <li class="breadcrumb-item"><a href="{{route('referee.index')}}">Referees</a></li>
                              <li class="breadcrumb-item"><a href="{{route('referee.index')}}">All Referees</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Add Referee</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                         <div class="card-body">
                      
                              <form class="form-horizontal tasi-form" method="POST" action="{{route('referee.store')}}" enctype="multipart/form-data" id="commentForm">
                                 @csrf()
                                 @method('POST')
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Full Name</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control @if ($errors->has('referee_fullname')) is-valid @endif"  name="referee_fullname" value="{{old('referee_fullname')}}" >
                                          <span class="help-block">@if ($errors->has('referee_fullname'))
                                                  {{ $errors->first('referee_fullname') }}
                                              @endif</span>
                                      </div>
                                  </div>
         
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Username</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control @if ($errors->has('referee_username')) is-valid @endif"  name="referee_username" value="{{old('referee_username')}}">
                                          <span class="help-block">@if ($errors->has('referee_username'))
                                                  {{ $errors->first('referee_username') }}
                                              @endif</span>
                                      </div>
                                  </div>

                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">E-mail</label>
                                      <div class="col-sm-10">
                                          <input type="email" class="required form-control @if ($errors->has('referee_email')) is-valid @endif"  name="referee_email" value="{{old('referee_email')}}">
                                          <span class="help-block">@if ($errors->has('referee_email'))
                                                  {{ $errors->first('referee_email') }}
                                              @endif</span>
                                      </div>
                                  </div>

                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Password </label>
                                      <div class="col-sm-10">
                                          <input type="password" class="required form-control @if ($errors->has('refree_password')) is-valid @endif"  name="refree_password" >
                                          <span class="help-block">@if ($errors->has('refree_password'))
                                                  {{ $errors->first('refree_password') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Confirm Password </label>
                                      <div class="col-sm-10">
                                          <input type="password" class="required form-control @if ($errors->has('refree_password')) is-valid @endif"  name="refree_password_confirmation" > 
                                      </div>
                                  </div>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label">Phone Number</label>
                                      <div class="col-sm-10">
                                          <input type="text" class="required form-control @if ($errors->has('referee_mobile')) is-valid @endif"  name="referee_mobile" value="{{old('referee_mobile')}}">
                                          <span class="help-block">@if ($errors->has('referee_mobile'))
                                                  {{ $errors->first('referee_mobile') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                          <label class="col-lg-2 control-label"  for="referee_image">Presonal Picture </label>
                                          <div class="col-lg-10">
                                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                                      <div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
                                                          <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" />
                                                      </div>
                                                      <div class="fileupload-preview fileupload-exists thumbnail" style="max-width: 200px; max-height: 150px; line-height: 20px;"></div>
                                                      <div>
                                                       <span class="btn btn-white btn-file">
                                                       <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select image</span>
                                                       <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                                       <input type="file" name="referee_image" class="default" value="{{old('referee_image')}}" />
                                                       </span>
                                                          
                                                          
                                                      </div>
                                                       <div class="form-text text-muted">
                                                             @if ($errors->has('referee_image'))
                                                                {{ $errors->first('referee_image') }}
                                                            @endif
                                                           </div>
                                                  </div>
                                          </div>
                                      </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label col-sm-2">Address Description</label>
                                      <div class="col-sm-10">
                                          <textarea class="  form-control   @if ($errors->has('referee_address')) is-valid @endif" name="referee_address" rows="2">{{old('referee_address')}}</textarea>
                                           <span class="help-block">@if ($errors->has('referee_address'))
                                                  {{ $errors->first('referee_address') }}
                                              @endif</span>
                                      </div>
                                      
                                    </div>
                                    <div class="form-group ">
                                        <label class="col-sm-2 control-label col-sm-2">Birthday Date</label>
                                        <div class="col-sm-10">
                                            <div class="input-group date dpYears" data-date-viewmode="years" data-date-format="dd-mm-yyyy" data-date="1-1-1970">
                                                <input type="text" class="form-control @if ($errors->has('referee_birthday')) is-valid @endif" placeholder="dd-mm-yyyy" aria-label="Right Icon" aria-describedby="dp-ig" name="referee_birthday" value="{{old('referee_birthday')}}">
                                                <div class="input-group-append">
                                                    <button id="dp-ig" class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar f14"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                        <span class="help-block">@if ($errors->has('referee_birthday'))
                                                  {{ $errors->first('referee_birthday') }}
                                              @endif</span>
                                    </div>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label">National ID </label>
                                      <div class="col-sm-10">
                                          <input type="text" class=" form-control @if ($errors->has('referee_nationl_identity')) is-valid @endif" id="namear" name="referee_nationl_identity" value="{{old('referee_nationl_identity')}}">
                                          <span class="help-block">@if ($errors->has('referee_nationl_identity'))
                                                  {{ $errors->first('referee_nationl_identity') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label"> ID  </label>
                                      <div class="col-sm-10">
                                          <input type="text" class=" form-control @if ($errors->has('referee_identity')) is-valid @endif" id="namear" name="referee_identity" value="{{old('referee_identity')}}">
                                          <span class="help-block">@if ($errors->has('referee_identity'))
                                                  {{ $errors->first('referee_identity') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Referee Type </label>
                                      <div class="col-sm-10">
                                          <select class="required  form-control @if ($errors->has('referee_type')) is-valid @endif" name="referee_type" >
                                             <option  value="" disabled="disabled" selected="">Select Type</option>
                                                        

                                                        <option value="A" @if( old('referee_type')== "A"){{"selected"}}@endif >A</option>
                                                        <option value="B" @if( old('referee_type')== "B"){{"selected"}}@endif >B</option>
                                                        <option value="C" @if( old('referee_type')== "C"){{"selected"}}@endif >C</option>
                                                       
                                          </select>
                                          <span class="help-block">@if ($errors->has('referee_type'))
                                                  {{ $errors->first('referee_type') }}
                                              @endif</span>
                                      </div>
                                  </div>

                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="{{route('referee.index')}}" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                        
                           
                         </div>
                      </section>
                </div>
              </div>
@endsection