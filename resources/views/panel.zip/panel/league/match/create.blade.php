@extends('layouts.app')
@section('content')

     <div class="row">
                  <div class="col-lg-12">
                      <!--breadcrumbs start -->
                      <nav aria-label="breadcrumb">
                          <ol class="breadcrumb">
                              <li class="breadcrumb-item"><a href="{{route('home')}}"><i class="fa fa-home"></i> Home</a></li>
                              <li class="breadcrumb-item"><a href="{{route('league.index')}}">Leagues</a></li>
                              <li class="breadcrumb-item"><a href="{{route('league.index')}}">All Leagues</a></li>
                              <li class="breadcrumb-item"><a href="{{route('leaguesMatches.index',$league->league_id)}}">{{$league->league_name}} Matches</a></li>
                              <li class="breadcrumb-item active" aria-current="page">Add Match</li>
                          </ol>
                      </nav>
                      <!--breadcrumbs end -->
                  </div>
              </div>
              <div class="row">
                <div class="col-lg-12">
                      <section class="card">
                         <div class="card-body">
                  
                              <form class="form-horizontal tasi-form" method="POST" action="{{route('leaguesMatches.store',$league->league_id)}}" enctype="multipart/form-data" id="commentForm">
                                 @csrf()
                                 @method('POST')
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Home Team </label>
                                      <div class="col-sm-10">
                                          <select class="required number form-control @if ($errors->has('home_team')) is-valid @endif" name="home_team" >
                                             <option  value="" disabled="disabled" selected="">Select Team</option>
                                                        @foreach($teams as $team)

                                                        <option value="{{$team->team_id}}" 
                                                        
                                                        @if(old('home_team') == $team->team_id)

                                                           {{"selected"}}
                                                        @endif >{{$team->team->team_name}}</option>
                                                       @endforeach
                                          </select>
                                          <span class="help-block">@if ($errors->has('home_team'))
                                                  {{ $errors->first('home_team') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Away Team </label>
                                      <div class="col-sm-10">
                                          <select class="required number form-control @if ($errors->has('away_team')) is-valid @endif" name="away_team" >
                                             <option  value="" disabled="disabled" selected="">Select Team</option>
                                                        @foreach($teams as $team)

                                                        <option value="{{$team->team_id}}" 
                                                        
                                                        @if(old('away_team') == $team->team_id)

                                                           {{"selected"}}
                                                        @endif >{{$team->team->team_name}}</option>
                                                       @endforeach
                                          </select>
                                          <span class="help-block">@if ($errors->has('away_team'))
                                                  {{ $errors->first('away_team') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Halls </label>
                                      <div class="col-sm-10">
                                          <select class="required number form-control @if ($errors->has('match_hall')) is-valid @endif" name="match_hall" >
                                             <option  value="" disabled="disabled" selected="">Select Halls</option>
                                                        @foreach($halls as $hall)

                                                        <option value="{{$hall->hall_id}}" 
                                                        
                                                        @if(old('match_hall') == $hall->hall_id)

                                                           {{"selected"}}
                                                        @endif >{{$hall->hall_name}}</option>
                                                       @endforeach
                                          </select>
                                          <span class="help-block">@if ($errors->has('match_hall'))
                                                  {{ $errors->first('match_hall') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <label class="col-sm-2 control-label">Select Referees </label>
                                      <div class="col-sm-10">
                                       
                                      

                                      <select class="required js-example-basic-multiple" multiple="multiple" name="referee_id[]" >
                                          @foreach($referees as $referee)

                                                        <option value="{{$referee->referee_id}}" 
                                                        
                                                        @if(old('referee_id') == $referee->referee_id)

                                                           {{"selected"}}
                                                        @endif >{{$referee->referee_fullname}}</option>
                                                       @endforeach
                                      </select>
                                 
                                          <!-- <select class="required number form-control @if ($errors->has('match_referee')) is-valid @endif" name="match_referee" >
                                             <option  value="" disabled="disabled" selected="">Select Referee</option>
                                                        @foreach($referees as $referee)

                                                        <option value="{{$referee->referee_id}}" 
                                                        
                                                        @if(old('match_referee') == $referee->referee_id)

                                                           {{"selected"}}
                                                        @endif >{{$referee->referee_fullname}}</option>
                                                       @endforeach
                                          </select> -->
                                          <span class="help-block">@if ($errors->has('referee_id'))
                                                  {{ $errors->first('referee_id') }}
                                              @endif</span>
                                      </div>
                                  </div>
                                  <div class="form-group ">
                                      <label class="control-label col-sm-2 ">Match Date </label>
                                      <div class="col-lg-10">
                                          <div class="input-group date form_datetime-component">
                                              <input type="text" class="form-control date-set" aria-label="Right Icon" name="match_date" aria-describedby="basic-addon12">
                                              <div class="input-group-append">
                                                  <button id="basic-addon12" class="btn btn-outline-secondary" type="button"><i class="fa fa-calendar f14"></i></button>
                                              </div>
                                          </div>
                                          <span class="help-block">@if ($errors->has('match_date'))
                                                  {{ $errors->first('match_date') }}
                                              @endif</span>
                                      </div>
                                  </div>
                              
                                  <div class="form-group">
                                      <div class="col-lg-offset-2 col-lg-4">
                                          <button class="btn btn-danger" type="submit">Save</button>
                                          <a href="{{route('leaguesMatches.index',$league->league_id)}}" class="btn btn-default" type="button">Cancel</a>
                                      </div>
                                  </div>
                              </form>
                        
                           
                         </div>
                      </section>
                </div>
              </div>
@endsection